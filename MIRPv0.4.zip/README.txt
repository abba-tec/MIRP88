MIDI Input to Roblox Piano (MIRP) v0.4 by GreatCorn

	Description: Converts MIDI Input from default MIDI Input ID and converts it into keystrokes, adapted to be used with Roblox piano.
This application was coded in Python 3.5 and uses such packages as pyHook, Ctypes and Pygame and was built with the use of cx_Freeze. I do not own any of these packages and the rights to them belong to their owners.

Note: with the use of pyHook and Ctypes for simulating keystrokes it is possible than an antivirus software may detect this program as a virus. I have no intentions to harm anyone's PC, but it is up to you to decide if either you should use this program or not. 

	Instructions: This program uses the default MIDI input ID to get all the data. Make sure a MIDI input device (MIDI keyboard/electro piano/etc) is connected to your PC before running the program. Upon running MIRP when a device is connected it will test for any input and then will convert it into keystrokes with the appropriate layout. The text will display what note number was sent the latest(I didn't use note names due to the rules of transposition and etc) and what symbol that corresponds to on the keyboard. The "Transpose out of range octaves" checkbox will transpose the octaves that are out of range of the Roblox piano an octave lower. The "Velocity threshold" slider is to be used to set up the velocity threshold, below which notes are not played(for example, setting the threshold to 64 and playing a note with a velocity of 64 or lower will not send a keystroke, but a note with a velocity of 65 or higher will).

To do list:
	-Add a transpose option;
	-Try porting to different platforms;
	-Pack the script into a single .exe for the sake of compactness(nothing except cx_Freeze worked for me).